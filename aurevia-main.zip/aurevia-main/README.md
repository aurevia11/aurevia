# Aurevia Invest

Aurevia Invest is a Next.js 14 application using TypeScript, PostgreSQL, Prisma, NextAuth, Socket.IO, Zustand, Tailwind CSS, Recharts and Lightweight Charts. Trading and market prices used by the trading engine remain internal simulations; the `/markets` dashboard separately displays live-provider quotes and history. This repository does not connect to a live broker, exchange, bank, or payment network.

## What is implemented

### User application
- Landing page, registration and credential login
- JWT sessions with USER/ADMIN role enforcement
- KYC profile submission, private identity-document uploads, and administrator review states
- Profile and account settings
- 2FA security flag
- Live dashboard with cash equity and open positions
- Realtime market ticker
- Trading terminal with Market, Limit and Stop orders
- Simulated order book and realtime candles/price chart
- Open-order cancellation
- One-click position close
- Unrealized P&L display
- Wallet balance from the ledger
- Deposit and withdrawal requests
- Funding history

### Administration
- Role-protected admin area
- User list and freeze/unfreeze
- Role changes
- KYC profile and private document approval/rejection
- Account restrictions and withdrawal enablement controls
- Deposit/withdrawal approval queue
- Force-close open positions
- Instrument enable/disable and configuration API
- System settings
- Audit log
- Realtime operational statistics

### Financial engine
- PostgreSQL persistence
- Prisma transactions
- Double-entry ledger
- Ledger balance derived from entries
- Serializable transactions for financial mutations
- Atomic funding approval
- Atomic trade reservation
- Margin release and realized P&L settlement
- Trading fees
- Insufficient-funds protection
- No direct mutable customer cash balance

### Market engine
- Internal simulated instruments
- Random-walk price engine
- One-minute candles
- Automatic Limit/Stop order processing
- Socket.io market:update events
- Socket.io trade:update events
- REST market, candle and order-book endpoints

### Live market dashboard

The `/markets` page uses the server-only `FINNHUB_API_KEY` when configured and falls back to Yahoo Finance's unofficial chart endpoint if Finnhub is unavailable or lacks an instrument. Quotes refresh every five seconds for the selected asset; watchlist quotes refresh every 30 seconds, and server-side in-process caching reduces duplicate provider requests. Historical OHLCV data supports the displayed ranges and is cached for up to one minute. Provider timestamps and source are shown, and the last successful quote is explicitly marked stale when reused; provider errors are never replaced with invented prices. Yahoo Finance is not an official API and can delay, limit, or discontinue access. Watchlists are stored on the device in separate public/account scopes. The ticker and chart are informational and are not connected to trade execution.

## Important scope boundary

The platform's funding and market environment is intentionally internal simulation. `BANK_SIM`, `CRYPTO_SIM`, and `INTERNAL_TRANSFER` are not bank, card, blockchain, custody, or exchange integrations. Connecting real customer money or external execution requires regulated providers, KYC/AML/sanctions controls, reconciliation, custody, licensing, security review and jurisdiction-specific compliance.

Two-factor authentication is currently disabled. The legacy database flag is not treated as protection, the profile API reports it as unavailable, and attempts to enable it are rejected until enrollment, login challenges, recovery, and reauthentication are implemented.

## Requirements

- Node.js 20+
- Docker Desktop or PostgreSQL 15+
- npm

## Isolated browser tests

Run `npm run test:e2e:isolated` with Docker available. The command starts a disposable PostgreSQL 16 container bound only to a dynamically selected loopback port, applies Prisma migrations only to that container, and removes it after the run. The container has no persistent volume; neither `DATABASE_URL` nor `DIRECT_URL` from `.env` is used for tests. `npm run test:e2e` requires explicit `AUREVIA_E2E_DATABASE_URL` and `AUREVIA_E2E_DIRECT_URL` values that point to the same local PostgreSQL database ending in `_e2e`; it refuses Supabase, Neon, and other remote hosts before fixture setup.

The isolated database bootstraps only the minimal Supabase Storage tables, private bucket metadata, and database roles required by the Storage-policy migration. The Playwright application process has Supabase URL/key configuration cleared, so file workflows fail closed and cannot access the shared Storage service. `npm run test:e2e` by itself continues to reject non-local or mismatched database URLs.

## Environment

Copy `.env.example` to `.env`.

`.env.example` lists variable names only. Configure the values in the ignored `.env` file or your deployment's secret manager. `DATABASE_URL` is the application connection (use the Supabase pooler URL when appropriate); Prisma uses `DIRECT_URL` for migrations and introspection. Both must point to the intended Supabase Postgres database. The application does not use a browser Supabase client; database access stays on the server through Prisma.

Only `NEXT_PUBLIC_APP_URL` and `NEXT_PUBLIC_SUPABASE_URL` are public configuration. All other values, especially database URLs, `NEXTAUTH_SECRET`, administrator credentials, SMTP credentials, verification API keys, and `SUPABASE_SERVICE_ROLE_KEY`, are server-only. Never put a Supabase service-role/secret key in a `NEXT_PUBLIC_` variable. The Data API roles `anon` and `authenticated` have no table or sequence privileges on the application's `public` schema, and row-level security is enabled for its tables; the application uses its server-side Prisma connection.

`ADMIN_USERNAME`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD` are used by the existing admin login and seed. Use a unique password of at least 12 characters. The seed updates the configured admin account, adopts an existing admin rather than creating another, and provisions an admin only when none exists.

Registration completes without an email/SMS ownership challenge by default. Set `REGISTRATION_VERIFICATION_ENABLED=true` to opt into contact verification; then configure `VERIFICATION_EMAIL_API_URL` and `VERIFICATION_EMAIL_API_KEY`, or set `PHONE_VERIFICATION_REQUIRED=true` and configure `VERIFICATION_SMS_API_URL` and `VERIFICATION_SMS_API_KEY`. Keep provider credentials server-only. `NEXT_PUBLIC_APP_URL`, `PORT`, and `MARKET_TICK_MS` are optional and have runtime defaults.

For production, set `NEXTAUTH_URL` and `NEXT_PUBLIC_APP_URL` to the canonical HTTPS domain configured for that deployment. Production startup rejects a missing `NEXTAUTH_SECRET` or `NEXTAUTH_URL`; it never trusts an arbitrary Host header to establish the auth origin. Official support contact defaults to `aureviainvest@gmail.com` and can be overridden with `SUPPORT_EMAIL`; `COMPLAINTS_EMAIL` may be set separately. Configure these destinations separately from `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, and `SMTP_FROM`. When SMTP is missing, password recovery is unavailable and support/funding actions report that no email was sent; in-app tickets and notifications remain recorded.

### Vercel deployment

This repository is configured as a Next.js application in `vercel.json`. Vercel runs the App Router routes as serverless functions; it does not run `server.ts`, persistent Socket.IO connections, or the local in-process market timer. Browser market views therefore refresh over HTTP, and the protected `/api/cron/market-tick` route advances the simulated DEMO market once per minute. Use a Vercel plan that supports a one-minute Cron schedule. This market is simulated; the job does not connect to a broker or funding provider.

- Framework preset: Next.js
- Install command: `npm ci`
- Build command: `npm run build`
- Output directory: leave the Vercel default
- No custom start command

Configure production and preview environment variables in the Vercel project settings. Required server values are `DATABASE_URL`, `DIRECT_URL`, `NEXTAUTH_SECRET`, `NEXTAUTH_URL`, `NEXT_PUBLIC_APP_URL`, and `CRON_SECRET`. Configure Supabase private-file variables (`SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`) when those workflows are enabled. Add `ADMIN_USERNAME`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD` before provisioning the administrator. Set the canonical HTTPS app origin explicitly in `NEXTAUTH_URL` and `NEXT_PUBLIC_APP_URL`; use a separate staging database and secrets for Preview deployments. Keep all credentials server-only except the explicitly public Supabase URL and anon key.

Use Supabase's pooled connection string for `DATABASE_URL` where appropriate and its direct PostgreSQL connection for `DIRECT_URL`. Apply reviewed Prisma migrations to the target database before promoting the deployment; the Vercel build does not run migrations or seed an administrator. Do not point Preview deployments at production customer data. Configure the four private Storage buckets and restrictive policies documented above before enabling uploads.

Generate a high-entropy `CRON_SECRET` and store it in Vercel project settings. Vercel Cron sends it as a Bearer token to the market-tick route; calls without that exact secret are rejected. Cron jobs run for production deployments. Local development and the Render Node service continue to use the custom server's ticker; Render remains the option when persistent Socket.IO/WebSocket delivery is required.

### Render deployment

Use a Render **Node web service** connected to the existing GitHub repository. Render's persistent web service supports this custom Next.js/Socket.IO HTTP server and WebSocket upgrades; do not deploy it as a static site or serverless function. Use one instance while the in-process Socket.IO market engine is enabled; horizontal scaling requires a shared Socket.IO adapter and coordinated market worker, which are not currently configured.

- Build command: `npm ci && npm run build`
- Start command: `npm start`
- Docker is not required for Render's native Node runtime. The checked-in multi-stage `Dockerfile` is an alternative if the Render service is explicitly configured as a Docker service.

Configure these variables in Render's environment settings (secrets stay in Render, never in source):

- Required: `DATABASE_URL`, `DIRECT_URL`, `NEXTAUTH_SECRET`, `NEXTAUTH_URL`, `NEXT_PUBLIC_APP_URL`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
- Optional according to enabled features: `ADMIN_USERNAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, SMTP/support variables, verification-delivery variables, `REGISTRATION_VERIFICATION_ENABLED`, `PHONE_VERIFICATION_REQUIRED`, and `MARKET_TICK_MS`. Leave `REGISTRATION_VERIFICATION_ENABLED=false` (the default) to allow registration and sign-in without an email/SMS ownership challenge; set it to `true` only when a verification provider is configured and contact verification is intended.

Set both `NEXTAUTH_URL` and `NEXT_PUBLIC_APP_URL` to the same canonical HTTPS origin assigned to the Render service (or its verified custom domain). The database URLs must be the existing Supabase PostgreSQL connections; use Supabase's pooler for application traffic when appropriate and its direct connection for Prisma schema management. Render injects these at runtime and `npm start` preserves them. Do not run `npm run db:migrate`, `db:push`, or a reset command automatically during release; schema changes require a separately reviewed and authorized operation.

The development command uses `.next-dev` so it does not collide with production builds in `.next`; `server.ts` loads the repository `.env` and honors the configured database URLs. The Docker build context excludes `.env*`; supply runtime configuration only through the hosting environment. The application has no production localhost URL dependency: its localhost URL fallback is for local development, and production startup requires `NEXTAUTH_URL`.

### REAL provider readiness

REAL execution is disabled in the application even if broker settings are present: `/api/orders` and the trading engine remain DEMO-only until a provider-specific integration, compliance review, and explicit execution enablement are implemented and tested. The current provider interfaces describe broker order submission/cancellation/status, balances/positions, reconciliation, quotes/bars, funding confirmations, identity/sanctions checks, and webhook signature verification; no external adapter is registered. The admin-only `/api/admin/providers/status` endpoint and Provider readiness panel report state/configuration presence without returning credential values. The broker webhook route verifies events only when a connected adapter is installed; it does not persist or reconcile events yet.

The names reserved for server-only broker configuration are `REAL_EXECUTION_ENABLED`, `BROKER_PROVIDER`, `BROKER_API_URL`, `BROKER_API_KEY`, `BROKER_ACCOUNT_ID`, and `BROKER_WEBHOOK_SECRET`. Payment-provider names are `PAYMENT_PROVIDER`, `PAYMENT_API_URL`, `PAYMENT_API_KEY`, and `PAYMENT_WEBHOOK_SECRET`. They are placeholders, not evidence that a provider is integrated or connected. No provider has been selected because intended customer jurisdictions are not specified. Select jurisdictions and obtain legal/compliance approval before evaluating broker, payment, market-data, and identity/AML providers. Manual administrator review cannot confirm a REAL deposit: REAL deposit approval and withdrawal approval/settlement are blocked pending provider integration. REAL investment requests may be reviewed but cannot be activated, completed, or settled until an investment-provider workflow exists. Manual KYC status is explicitly an administrator review and is not external identity/AML or regulatory verification.

Private file workflows require server-only `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`. The key must never be placed in a `NEXT_PUBLIC_*` variable or imported into client components. Configure these existing private buckets (the application does not create buckets): `kyc-documents` (10 MB), `profile-avatars` (5 MB), `wallet-receipts` (10 MB), and `support-attachments` (10 MB). Their restrictive `storage.objects` RLS policies are `aurevia_kyc_documents_block_client_access`, `aurevia_profile_avatars_block_client_access`, `aurevia_wallet_receipts_block_client_access`, and `aurevia_support_attachments_block_client_access`; each blocks all operations by `anon` and `authenticated` for its bucket. Trusted server routes use the service role only after session, record-ownership, or administrator checks. New object keys use `<userId>/<generated-UUID>.<extension>`. Upload routes verify signatures, MIME type, extension, size, and owning database record; file replacement is non-upserting and owner-scoped. File access uses signed URLs for at most five minutes. Users can retrieve their own KYC documents through the owner-filtered document route; administrator KYC review requires `requireAdmin`. KYC accepts JPEG, PNG, WebP, and PDF up to 8 MB; administrators can review uploaded files from `/admin`. No external identity, AML, sanctions, or malware-scanning provider is connected.

### Provider status and safe fallbacks

| Capability | Provider/configuration | Current behavior without provider |
| --- | --- | --- |
| Database | Supabase Postgres; `DATABASE_URL`, `DIRECT_URL` | Server operations fail explicitly; no in-memory financial fallback |
| Market information | Finnhub when `FINNHUB_API_KEY` is configured; Yahoo Finance chart endpoint as an unofficial fallback | Live market screens show provider source and freshness; provider failures show unavailable/stale data; internal prices are separately labelled simulated |
| Broker/execution | Provider contract only; no broker adapter or credentials | REAL execution path is disabled and rejected; only DEMO orders are simulated |
| Deposits and withdrawals | Funding-provider contract only; no bank, card, blockchain, or custody adapter | REAL deposit approval and manual withdrawal settlement are blocked; no external transfer is claimed |
| REAL investments | No investment execution/settlement provider | Requests may be reviewed, but activation, completion, and settlement are blocked |
| Identity/KYC | No identity verification provider configured | Documents/details can be submitted for human review only; approval is an administrator decision |
| Email/OTP | SMTP settings and verification delivery URL/key pairs | No email/SMS is claimed sent; verification-dependent actions report unavailable |
| Private files | Supabase Storage URL, private bucket, service-role key | Upload and signed access fail closed; no public-file fallback |
| Deployment | No deployment provider configuration is checked into this repository | Production secret injection, domains, TLS, backups, monitoring, and release controls must be configured in the hosting environment |
| SMS/OTP | `VERIFICATION_SMS_API_URL`, `VERIFICATION_SMS_API_KEY` | SMS verification cannot be completed; when required, registration fails closed |

Password recovery tokens are random, single-use, expire after 30 minutes, and are stored only as SHA-256 hashes. Resetting a password revokes the active account session. Successful and failed credential attempts are written to the existing admin-only audit log with a validated IP when available, bounded user-agent text, and a hashed identifier for unknown accounts; no password or raw token is stored.

For a real deployment, use a unique high-entropy `NEXTAUTH_SECRET`, a strong administrator password, and managed secret storage.

## Local setup

```bash
npm install
cp .env.example .env
# For the local Postgres container, set DATABASE_URL and DIRECT_URL to its connection URL.
docker compose up -d postgres
npx prisma generate
npm run db:migrate
npm run db:seed
npm run typecheck
npm test
npm run build
npm run dev
```

Open `http://localhost:3000`.

The application server owns the HTTP server and Socket.io endpoint, so use `npm run dev` rather than `next dev` when realtime functionality is required.

## Administrator provisioning

```text
Username: configured with ADMIN_USERNAME
Email: configured with ADMIN_EMAIL
Password: configured with ADMIN_PASSWORD
```

Set `ADMIN_USERNAME`, `ADMIN_EMAIL`, and a unique, strong `ADMIN_PASSWORD` in an ignored `.env` file or managed secret store, then run `npm run db:seed`. No administrator password is included in the repository. The seed refuses to run without these values.

## Docker

```bash
docker compose up --build
```

The included compose file starts PostgreSQL and the app. It requires the database, NextAuth, and administrator values from `.env`; it contains no default credentials.

## Test workflow

### 1. Health

Open:

```text
GET /api/health
```

Expected response includes `ok: true` and `database: "ok"`.

### 2. Admin login

Open `/login` and use the configured administrator credentials. `/admin` must be accessible only to an ADMIN JWT.

### 3. User registration

Create a normal account from `/register`, sign in, and confirm `/dashboard`, `/trade`, `/wallet`, `/kyc` and `/settings` are protected routes.

### 4. KYC

Submit the KYC form and upload an identity document to private storage. Admin reviews the file first, then approves/rejects the overall verification from `/admin`. Real-account funding requires an approved KYC profile and approved identity document.

### 5. Funding

Create a deposit request in `/wallet`. Admin approves it. The customer's USD ledger balance increases through a double-entry transaction.

Create a withdrawal request. Approval checks available ledger balance inside a serializable database transaction before posting the debit.

### 6. Trading

After funding a user account:

1. Open `/trade`.
2. Select an instrument.
3. Place a Market order.
4. Confirm an execution and position appear.
5. Watch the price update through Socket.io.
6. Confirm unrealized P&L changes.
7. Close the position.
8. Confirm margin plus realized P&L is returned to the user ledger.

For Limit and Stop orders, place an order outside the current trigger price, then wait for the market simulator to reach its trigger. The server processes eligible open orders on market ticks.

### 7. Ledger invariant

Every posted monetary transaction contains exactly one debit and one credit for the same amount. The test suite also covers positive monetary quantities.

### 8. Admin controls

From `/admin`, test:

- Freeze/unfreeze a user
- Approve/reject KYC
- Change USER/ADMIN role
- Approve/reject funding
- Force-close positions
- Enable/disable instruments

Client stories are private drafts until an administrator links and verifies the client, records a completed REAL withdrawal with its settlement reference, records publication consent, and approves the story. The repository does not include the supplied story photos or a configured image-storage provider, so seeded drafts have no image reference. No story, financial amount, or verification badge is published by seeding.
- Change system settings
- Inspect audit logs

### 9. API checks

Useful endpoints:

```text
GET  /api/health
GET  /api/market
GET  /api/candles?instrumentId=<id>&limit=100
GET  /api/orderbook?instrumentId=<id>
GET  /api/orders
POST /api/orders
DELETE /api/orders
GET  /api/positions
POST /api/positions
GET  /api/wallet
POST /api/wallet
GET  /api/kyc
POST /api/kyc
```

## Production hardening checklist

Before any real-money use, add and independently verify:

- Managed PostgreSQL with backups and point-in-time recovery
- Distributed rate limiting rather than process-memory rate limiting
- TOTP/WebAuthn 2FA with recovery codes
- Email/phone verification
- Independent KYC verification provider and document malware scanning
- AML and sanctions screening
- Real payment/custody integrations
- External market-data and execution integrations
- Reconciliation jobs
- Idempotency keys for every financial POST operation
- CSRF/origin controls appropriate to the deployment topology
- Structured security logging and alerting
- Secrets manager
- WAF/DDoS controls
- Database connection pooling
- Penetration testing
- Dependency/SBOM scanning
- Disaster recovery testing
- Regulatory review for every operating jurisdiction

## Project structure

```text
app/
  api/                 REST API routes
  admin/               admin control center
  dashboard/           portfolio dashboard
  trade/               trading terminal
  wallet/              funding interface
  kyc/                 KYC interface
  settings/            account settings
  login/               authentication UI
  register/            onboarding UI
components/            reusable React components
lib/                    authentication, ledger, market and order engines
prisma/                 schema and seed
server.ts               Next.js + Socket.io application server
tests/                  automated tests
Dockerfile              application image
docker-compose.yml      PostgreSQL + application orchestration
```

## Final implemented application surface

The current source includes:

- Dedicated `/admin/login` administrator entry point with role enforcement.
- Realtime Socket.io market ticks and execution broadcasts.
- Synthetic depth/order-book endpoint at `/api/orderbook`.
- Historical candle endpoint at `/api/candles`.
- User ledger transaction endpoint at `/api/ledger`.
- Full order retrieval and cancellation API.
- Market, limit and stop order triggering.
- Serializable order execution and leverage-aware margin reservation.
- Trading-fee ledger postings.
- Open-position unrealized P&L on the dashboard and trading terminal.
- Pending-withdrawal balance reservation checks.
- Admin instrument creation, enable/disable, price and leverage editing.
- Admin self-protection against freezing or demoting the currently logged-in administrator.
- Global loading, error and not-found UI states.
- Health endpoint suitable for container/load-balancer checks.

## Verification evidence

A repository-wide TypeScript/TSX parser scan was run after the final source edits and returned `parse_errors=0`.

A full dependency installation and therefore a complete `typecheck`, Prisma generation, Next production build and browser E2E run could not be completed in the execution environment because `npm install --no-audit --no-fund` timed out. Those commands remain the authoritative final verification commands on a machine with normal npm registry access.

Run:

```bash
npm install
npx prisma generate
npm run db:push
npm run db:seed
npm run typecheck
npm test
npm run build
npm run dev
```

This remains a simulated/internal trading and accounting platform. It is not, by itself, a licensed real-money brokerage, payment processor, custodian, KYC provider, or external execution venue.

## Aurevia stability and UX upgrade (2026-09)

This revision incorporates the recurring issues identified during the Aurevia deployment journey:

- Explicit client-side registration/login actions prevent the browser's native form GET from racing React hydration.
- Registration and login now expose network/API failures instead of silently stalling.
- Authentication keeps the existing NextAuth JWT session model; logout returns to `/login` without invalidating a valid session on ordinary refresh.
- A single startup shell provides an 8-second first-entry animation and a 3-second transition for subsequent route changes. It uses session storage to avoid an endless loading loop.
- The loading UI is finite and deterministic; there is no perpetual page reload or blinking redirect loop.
- Mobile navigation is full-width, touch-friendly, and avoids desktop side gutters/zoom-style layouts.
- The Aurevia metallic gold emblem supplied in the project assets is included at `public/aurevia-logo.png` and used in startup, navigation, login, registration, and the landing page.
- The interface uses a forest-green/black/gold visual system and broker-style trading cards, market views, order ticket, positions, notifications, KYC and account controls.
- The Stanbic IBTC E-Trade page was used only as a UX/functionality reference: mobile/web trading, live market data, account control, order workflows, portfolio visibility and trade notifications. Proprietary logos, copy, artwork and source code are not copied.

### Regression checklist

1. First visit: startup overlay completes once in 8 seconds.
2. Internal navigation: transition completes in 3 seconds.
3. Browser refresh: session is not deliberately cleared.
4. Logout: returns to login and does not trigger an infinite startup/redirect loop.
5. Registration: no native `/register?` submission; request goes to `/api/register` only after the user presses Continue.
6. Login: failed authentication shows an error and does not silently hang.
7. Mobile: navigation opens as an overlay and content remains within the viewport.
8. Branding: supplied Aurevia logo is loaded from the app's public assets.
